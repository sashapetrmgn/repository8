'''from django import forms
import jsonschema
import json
from django.core.exceptions import ValidationError

ALBUM_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string", "minLength": 1},
        "artist": {"type": "string", "minLength": 1},
        "year": {"type": "integer", "minimum": 1900, "maximum": 2030},  
        "tracks": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["title", "artist", "year"]
}

class AlbumForm(forms.Form):
    title = forms.CharField(max_length=200, required=True, label="Название альбома")
    artist = forms.CharField(max_length=200, required=True, label="Артист")
    year = forms.IntegerField(min_value=1900, max_value=2030, required=True, label="Год выпуска")
    tracks = forms.CharField(widget=forms.Textarea, required=True, label="Добавьте треки")

    def clean_tracks(self):
        tracks_str = self.cleaned_data.get('tracks', '')
        if tracks_str:
            
            tracks = [track.strip() for track in tracks_str.split(',') if track.strip()]
            return tracks
        return []

    def to_json(self):
        return {
            'title': self.cleaned_data['title'],
            'artist': self.cleaned_data['artist'],
            'year': self.cleaned_data['year'],
            'tracks': self.cleaned_data['tracks']
        }


class UploadFileForm(forms.Form):
    file = forms.FileField(required=True, label="Выберите JSON-файл", help_text="Файл должен быть в формате JSON с данными альбома")  

    def clean_file(self):
        file = self.cleaned_data['file']
        if not file:
            raise ValidationError("Файл обязателен для загрузки.")
        
        
        if not file.name.endswith('.json'):
            raise ValidationError("Файл должен иметь расширение .json.")
        
        
        max_size = 10 * 1024 * 1024  
        file_content_bytes = file.read()
        if len(file_content_bytes) > max_size:
            raise ValidationError(f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
        
        
        try:
            file_content = file_content_bytes.decode('utf-8')
            if not file_content.strip():
                raise ValidationError("Файл пустой или содержит только пробелы.")
            
            data = json.loads(file_content)
            jsonschema.validate(instance=data, schema=ALBUM_SCHEMA)
            
        except json.JSONDecodeError as e:
            raise ValidationError(f"Неверный формат JSON: {str(e)}")
        except jsonschema.exceptions.ValidationError as e:
            raise ValidationError(f"Данные не соответствуют схеме: {str(e)}")
        except UnicodeDecodeError as e:
            raise ValidationError(f"Проблема с кодировкой файла: {str(e)}. Используйте UTF-8.")
        
        
        file.seek(0)
        return file'''

'''from django import forms
import json
import jsonschema
from django.core.exceptions import ValidationError
from .models import Album

ALBUM_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string", "minLength": 1},
        "artist": {"type": "string", "minLength": 1},
        "year": {"type": "integer", "minimum": 1900, "maximum": 2030},
        "tracks": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["title", "artist", "year"]
}

from django import forms
from .models import Album

class AlbumForm(forms.Form):
    title = forms.CharField(max_length=100, label="Название альбома")
    artist = forms.CharField(max_length=100, label="Исполнитель")
    year = forms.IntegerField(min_value=1900, max_value=2100, label="Год выпуска")
    tracks = forms.CharField(widget=forms.Textarea, label="Треки (через запятую)")
    
    # Новое поле для выбора источника
    source = forms.ChoiceField(
        choices=[('file', 'Сохранить в файл JSON'), ('db', 'Сохранить в базу данных')],
        widget=forms.RadioSelect,
        label="Источник данных",
        initial='db'  # По умолчанию база данных
    )

    def clean_tracks(self):
        tracks_str = self.cleaned_data.get('tracks', '')
        if tracks_str:
            tracks = [track.strip() for track in tracks_str.split(',') if track.strip()]
            return tracks
        return []

    def to_json(self):
        return {
            'title': self.cleaned_data['title'],
            'artist': self.cleaned_data['artist'],
            'year': self.cleaned_data['year'],
            'tracks': self.cleaned_data['tracks']
        }

class EditAlbumForm(forms.ModelForm):
    tracks = forms.CharField(widget=forms.Textarea, required=True, label="Добавьте треки")

    class Meta:
        model = Album
        fields = ['title', 'artist', 'year', 'tracks']

    def clean_tracks(self):
        tracks_str = self.cleaned_data['tracks']
        tracks = [track.strip() for track in tracks_str.split(',') if track.strip()]
        if not tracks:
            raise forms.ValidationError("Должен быть хотя бы один трек.")
        return tracks

class UploadFileForm(forms.Form):
    file = forms.FileField(required=True, label="Выберите JSON-файл", help_text="Файл должен быть в формате JSON с данными альбома")

    def clean_file(self):
        file = self.cleaned_data['file']
        if not file:
            raise ValidationError("Файл обязателен для загрузки.")
        
        if not file.name.endswith('.json'):
            raise ValidationError("Файл должен иметь расширение .json.")
        
        max_size = 10 * 1024 * 1024  # 10MB
        file_content_bytes = file.read()
        if len(file_content_bytes) > max_size:
            raise ValidationError(f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
        
        try:
            file_content = file_content_bytes.decode('utf-8')
            if not file_content.strip():
                raise ValidationError("Файл пустой или содержит только пробелы.")
            
            data = json.loads(file_content)
            jsonschema.validate(instance=data, schema=ALBUM_SCHEMA)
            
        except json.JSONDecodeError as e:
            raise ValidationError(f"Неверный формат JSON: {str(e)}")
        except jsonschema.exceptions.ValidationError as e:
            raise ValidationError(f"Данные не соответствуют схеме: {str(e)}")
        except UnicodeDecodeError as e:
            raise ValidationError(f"Проблема с кодировкой файла: {str(e)}. Используйте UTF-8.")
        
        file.seek(0)
        return file
'''


from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from .models import CreditApplication

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True, help_text='Обязательное поле. Введите ваш email.')

    class Meta:
        model = get_user_model()
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user

class CreditApplicationForm(forms.ModelForm):
    class Meta:
        model = CreditApplication
        fields = ['full_name', 'amount', 'income', 'loan_term']
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Ваше полное имя'}),
            'amount': forms.NumberInput(attrs={'min': 1000}),
            'income': forms.NumberInput(attrs={'min': 0}),
            'loan_term': forms.NumberInput(attrs={'min': 1}),
        }


# Предположим, что у вас есть модели: CreditApplication, User
# Определим выбор таблиц
TABLE_CHOICES = [
    ('creditapplication', 'Заявки'),
    ('auth_user', 'Пользователи'),
    # добавьте другие таблицы по необходимости
]

# Для каждого варианта таблицы — список полей (здесь заранее указано)
FIELDS_CHOICES = {
    'creditapplication': [
        ('pk', 'ID заявки'),
        ('full_name', 'ФИО'),
        ('status', 'Статус'),
        ('created_at', 'Дата создания'),
    ],
    'auth_user': [
        ('id', 'ID'),
        ('username', 'Логин'),
        ('email', 'Email'),
        ('is_staff', 'Статус (админ)'),
    ],
}

class ReportForm(forms.Form):
    tables = forms.MultipleChoiceField(
        choices=TABLE_CHOICES,
        widget=forms.CheckboxSelectMultiple,
        label='Таблицы'
    )
    fields = forms.MultipleChoiceField(
        choices=[],
        widget=forms.CheckboxSelectMultiple,
        label='Поля'
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Можно динамически обновлять поля в зависимости от выбранных таблиц
        # Но для простоты сделаем статично
        all_fields = []
        for table, fields in FIELDS_CHOICES.items():
            for field_value, field_label in fields:
                all_fields.append((f'{table}.{field_value}', f'{table} - {field_label}'))
        self.fields['fields'].choices = all_fields