from datetime import date, timedelta 
from decimal import Decimal
from django.test import TestCase, Client
from django.core.exceptions import ValidationError
from django.db.utils import IntegrityError
from django.utils import timezone
from .models import CustomUser, LoanProduct, CreditApplication
from django.contrib.auth import get_user_model
from django.forms import ValidationError
from .forms import CustomUserCreationForm, CreditApplicationForm, ReportForm
from .models import LoanProduct
import openpyxl
from django.urls import reverse
from django.contrib.messages import get_messages
from io import BytesIO
from django.db import connection

class ModelCreationAndRelationTests(TestCase):
    def setUp(self):
        # Создаём пользователя для тестов
        self.user = CustomUser.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='securepassword123',
            phone_number='+79001234567',
            date_of_birth=date(1985, 3, 20)  # ← Важно: передаём объект date, а не строку!
        )

        # Создаём продукт кредита
        self.product = LoanProduct.objects.create(
            name='Ипотека',
            max_amount=50000000,
            term_months=12,
            interest_rate=11.5
        )

    def test_user_creation(self):
        user = CustomUser.objects.get(username='testuser')
        # Исправление: сравниваем объекты date, а не строку
        self.assertEqual(user.date_of_birth, date(1985, 3, 20))  # ✅ Правильно: date(1985, 3, 20)

    def test_loan_product_creation(self):
        self.assertEqual(self.product.name, 'Ипотека')
        self.assertEqual(self.product.max_amount, 50000000)
        self.assertEqual(self.product.interest_rate, 11.5)

    def test_credit_application_creation_and_relations(self):
        application = CreditApplication.objects.create(
            user=self.user,
            product=self.product,
            amount=1500000,
            status='pending',
            full_name='Иван Иванов',
            income=700000,
            loan_term=24,
            interest_rate=11.5
        )

        # Проверка связей
        self.assertEqual(application.user, self.user)
        self.assertEqual(application.product, self.product)
        self.assertEqual(application.status, 'pending')
        self.assertEqual(application.amount, 1500000)

        # Проверка обратных связей (related_name)
        self.assertIn(application, self.user.credit_applications.all())
        self.assertIn(application, self.product.applications.all())


class TimeStampAutoPopulationTests(TestCase):

    def test_auto_now_add_and_auto_now(self):
        """
        Убедиться, что поля created_at и updated_at автоматически заполняются
        и обновляются при сохранении.
        """
        user = CustomUser.objects.create(username='timeuser')
        self.assertIsNotNone(user.created_at)
        self.assertIsNotNone(user.updated_at)
        self.assertAlmostEqual(user.created_at, user.updated_at, delta = timedelta(seconds=1))

        # Имитация течения времени и обновление объекта
        old_updated_at = user.updated_at
        user.address = "New Address"
        user.save()

        # created_at не должен меняться при обновлении
        self.assertEqual(user.created_at, user.created_at)
        # updated_at должен обновиться и стать новее
        self.assertGreater(user.updated_at, old_updated_at)


class ModelValidationTests(TestCase):
    # Примечание: Django автоматически не вызывает full_clean() при save(),
    # но ORM проверяет некоторые ограничения (например, null=False, unique=True).

    def test_status_choices_validation(self):
        """Проверка, что недопустимый выбор статуса вызывает ошибку ValidationError."""
        user = CustomUser.objects.create(username='validuser')
        product = LoanProduct.objects.create(name='Valid Product', max_amount=1000, interest_rate=5, term_months=12)
        
        # Мы используем .full_clean(), чтобы принудительно запустить валидацию полей выбора (choices)
        app = CreditApplication(
            user=user,
            product=product,
            full_name='Test Name',
            income=Decimal('1000'),
            amount=Decimal('100'),
            loan_term=12,
            interest_rate=5,
            status='invalid_status' # Недопустимое значение
        )
        with self.assertRaises(ValidationError):
            app.full_clean()

    def test_unique_username_constraint(self):
        """Проверка ограничения уникальности для имени пользователя (унаследовано от AbstractUser)."""
        CustomUser.objects.create(username='uniqueuser')
        
        # Попытка создать пользователя с тем же именем должна вызвать IntegrityError при сохранении в БД
        with self.assertRaises(IntegrityError):
             # .save() напрямую взаимодействует с БД, где срабатывает ограничение UNIQUE
            CustomUser.objects.create(username='uniqueuser')

class FormTests(TestCase):

    def setUp(self):
        """Подготовка необходимых данных для тестов форм."""
        self.user = CustomUser.objects.create_user(username='testuser', email='test@example.com', password='password123')
        self.product = LoanProduct.objects.create(name='Ипотека', max_amount=Decimal('100000'), interest_rate=10, term_months=12)

    # --- Тесты для CustomUserCreationForm (Форма регистрации) ---

    def test_user_creation_form_valid_data(self):
        """Проверка валидности формы регистрации с корректными данными."""
        form_data = {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password1': 'StrongP@ssw0rd',
            'password2': 'StrongP@ssw0rd',
        }
        form = CustomUserCreationForm(data=form_data)
        self.assertTrue(form.is_valid())
        user = form.save()
        self.assertEqual(user.username, 'newuser')
        self.assertEqual(user.email, 'newuser@example.com')

    def test_user_creation_form_invalid_data(self):
        """Проверка невалидности формы регистрации с некорректными данными."""
        # Пароли не совпадают, email отсутствует
        form_data = {
            'username': 'invaliduser',
            'email': '',
            'password1': 'pass1',
            'password2': 'pass2',
        }
        form = CustomUserCreationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('email', form.errors)
        self.assertIn('password2', form.errors) # Ошибка "Пароли не совпадают"

    # --- Тесты для CreditApplicationForm ---

    def test_credit_application_form_valid_data(self):
        """Проверка валидности формы заявки на кредит с корректными данными."""
        form_data = {
            'full_name': 'Иван Иванов',
            'amount': '50000.00',
            'income': '70000.00',
            'loan_term': 60,
        }
        form = CreditApplicationForm(data=form_data)
        # ModelForms требуют наличия связанных объектов в базе для успешного сохранения,
        # но is_valid() проверяет только данные формы.
        self.assertTrue(form.is_valid())

    def test_credit_application_form_invalid_data(self):
        """Проверка невалидности формы заявки на кредит (например, сумма меньше минимальной)."""
        form_data = {
            'full_name': '', # Обязательное поле пусто
            'amount': '500.00', # Меньше, чем минимальное значение 1000 в виджете
            'income': '-100.00', # Меньше, чем 0
            'loan_term': 0, # Меньше, чем 1
        }
        form = CreditApplicationForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('full_name', form.errors)
        # В данном случае, ограничения min/max заданы через виджеты HTML,
        # Django ModelForm по умолчанию их строго не валидирует на уровне is_valid(),
        # но мы можем добавить кастомную валидацию в форму или модели при необходимости.
        # ORM проверит null=True/False.

    # --- Тесты для ReportForm ---

    def test_report_form_valid_data(self):
        """Проверка валидности формы отчета с корректными данными (выбраны таблицы и поля)."""
        form_data = {
            'tables': ['creditapplication', 'auth_user'],
            'fields': ['creditapplication.status', 'auth_user.username'],
        }
        form = ReportForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_report_form_invalid_data(self):
        """Проверка невалидности формы отчета с некорректными данными (неверный выбор поля)."""
        form_data = {
            'tables': ['creditapplication'],
            'fields': ['invalid_table.invalid_field'], # Этого поля нет в choices
        }
        form = ReportForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('fields', form.errors)

class FullViewTests(TestCase):

    def setUp(self):
        self.client = Client()
        self.user_password = 'password123'
        self.user = CustomUser.objects.create_user(
            username='testuser',
            email='test@example.com',
            password=self.user_password
        )
        self.admin_password = 'adminpassword123'
        self.admin_user = CustomUser.objects.create_superuser(
            username='adminuser',
            email='admin@example.com',
            password=self.admin_password
        )
        self.product = LoanProduct.objects.create(
            name='Ипотека',
            max_amount=Decimal('100000'),
            interest_rate=10,
            term_months=12
        )
        self.application = CreditApplication.objects.create(
            user=self.user,
            product=self.product,
            full_name='Тест Заявка',
            income=Decimal('50000'),
            amount=Decimal('10000'),
            loan_term=12,
        )

    # --- Тестирование Аутентификации (Login/Logout/Register Views) ---

    def test_login_view_success(self):
        """Проверка успешного входа в систему."""
        response = self.client.post(reverse('creditapp:login'), {
            'username': 'testuser',
            'password': self.user_password
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['user'].is_authenticated)
        self.assertRedirects(response, reverse('creditapp:home'))

    def test_login_view_failure(self):
        """Проверка неудачного входа с неверными данными."""
        response = self.client.post(reverse('creditapp:login'), {
            'username': 'testuser',
            'password': 'wrongpassword'
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['user'].is_authenticated)
        # Проверка сообщения об ошибке
        messages = list(get_messages(response.wsgi_request))
        self.assertEqual(len(messages), 1)
        self.assertEqual(str(messages[0]), 'Неверные учетные данные') # Исправлено обращение к сообщению

    def test_logout_view(self):
        """Проверка выхода из системы."""
        self.client.login(username='testuser', password=self.user_password)
        response = self.client.get(reverse('creditapp:logout'), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['user'].is_authenticated)
        self.assertRedirects(response, reverse('creditapp:home'))

    def test_register_view_success(self):
        """Проверка успешной регистрации нового пользователя."""
        response = self.client.post(reverse('creditapp:register'), {
            'username': 'newreguser',
            'email': 'newreguser@example.com',
            'password1': 'StrongP@ssw0rd',
            'password2': 'StrongP@ssw0rd',
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['user'].is_authenticated)
        self.assertRedirects(response, reverse('creditapp:home'))
        self.assertTrue(CustomUser.objects.filter(username='newreguser').exists())

    # --- Тестирование доступа и CRUD операций для обычных пользователей ---

    def test_application_list_access(self):
        """Авторизованный пользователь может видеть свой список заявок."""
        self.client.login(username='testuser', password=self.user_password)
        response = self.client.get(reverse('creditapp:application_list'))
        self.assertEqual(response.status_code, 200)
        
      
        self.assertContains(response, str(self.application.amount)) # Проверяем сумму заявки

        # Проверим, что пользователь видит только свои заявки
        other_user = CustomUser.objects.create_user(username='other', password='p')
        # Создаем вторую заявку с другой суммой для проверки изоляции данных
        app2 = CreditApplication.objects.create(user=other_user, product=self.product, full_name='Чужая заявка', amount=20000, income=1000, loan_term=12)
        response = self.client.get(reverse('creditapp:application_list'))
        self.assertNotContains(response, str(app2.amount)) # Убеждаемся, что чужая сумма не видна

    def test_create_application_view_post_valid_data(self):
        """Проверка создания новой заявки через View."""
        self.client.login(username='testuser', password=self.user_password)
        initial_count = CreditApplication.objects.count()
        form_data = {
            'full_name': 'Новый Кандидат',
            'amount': '20000.00',
            'income': '80000.00',
            'loan_term': 36,
        }
        # ИСПОЛЬЗУЕМ ПРАВИЛЬНОЕ ИМЯ URL: 'creditapp:add_application'
        response = self.client.post(reverse('creditapp:add_application'), data=form_data, follow=True)
        self.assertEqual(CreditApplication.objects.count(), initial_count + 1)
        self.assertRedirects(response, reverse('creditapp:application_list'))
        new_app = CreditApplication.objects.get(full_name='Новый Кандидат')
        self.assertEqual(new_app.user, self.user)

    # --- Тестирование доступа администратора (user_passes_test(is_admin)) ---

    def test_admin_dashboard_access(self):
        """Проверка доступа администратора к админ-панели."""
        self.client.login(username='adminuser', password=self.admin_password)
        response = self.client.get(reverse('creditapp:admin_dashboard'))
        self.assertEqual(response.status_code, 200)
        # ИСПОЛЬЗУЕМ assertTemplateUsed ВМЕСТО assertContains ДЛЯ ПРОВЕРКИ ШАБЛОНА
        self.assertTemplateUsed(response, 'creditapp/admin_dashboard.html')
        self.assertContains(response, 'Административная панель')

    def test_admin_dashboard_access_denied_for_user(self):
        """Проверка отказа в доступе обычному пользователю к админ-панели."""
        self.client.login(username='testuser', password=self.user_password)
        response = self.client.get(reverse('creditapp:admin_dashboard'))
        self.assertEqual(response.status_code, 302) # Должен перенаправить на страницу логина/ошибки доступа

    def test_admin_delete_application(self):
        """Администратор может удалить заявку через POST-запрос."""
        self.client.login(username='adminuser', password=self.admin_password)
        app_pk = self.application.pk
        response = self.client.post(reverse('creditapp:delete_application', args=[app_pk]), follow=True)
        
        self.assertEqual(response.status_code, 200)
        self.assertFalse(CreditApplication.objects.filter(pk=app_pk).exists())
        messages = list(get_messages(response.wsgi_request))
        self.assertEqual(str(messages[0]), 'Заявка успешно удалена.') 

    # --- Тестирование Функционала Отчетов Excel ---
    
    def test_generate_report_view(self):
        """Проверка генерации Excel отчета администратором."""
        self.client.login(username='adminuser', password=self.admin_password)
        form_data = {
            'tables': ['creditapplication'],
            'fields': ['creditapplication.full_name', 'creditapplication.status'],
        }
        # ИСПОЛЬЗУЕМ ПРАВИЛЬНОЕ ИМЯ URL: 'creditapp:admin_report'
        response = self.client.post(reverse('creditapp:admin_report'), data=form_data)
        
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        self.assertIn('attachment; filename=report.xlsx', response['Content-Disposition'])

        # Чтение сгенерированного файла для проверки содержимого
        workbook = openpyxl.load_workbook(BytesIO(response.content))
        sheet = workbook.active
        self.assertEqual(sheet['A1'].value, 'full_name')
        self.assertEqual(sheet['B1'].value, 'status')
        self.assertEqual(sheet['A2'].value, 'Тест Заявка')
        self.assertEqual(sheet['B2'].value, 'pending')

    def test_full_credit_application_cycle(self):
        """
        Интеграционный тест: Пользователь логинится -> подает заявку -> 
        проверяет, что заявка появилась в списке и в БД.
        """
        username = 'cycle_user'
        password = 'cycle_password123'
        user = CustomUser.objects.create_user(username=username, password=password, email='cycle@example.com')
        
        # 1. Залогиниться под новым пользователем
        self.client.login(username=username, password=password)

        # 2. Проверить количество заявок до подачи
        initial_count = CreditApplication.objects.filter(user=user).count()
        self.assertEqual(initial_count, 0)

        # 3. Подготовить валидные данные для формы заявки
        form_data = {
            'full_name': 'Интеграционный Тест',
            'amount': '150000.00',
            'income': '90000.00',
            'loan_term': 120,
        }

        # 4. Отправить POST-запрос на создание заявки (используя правильное имя URL: 'creditapp:add_application')
        create_url = reverse('creditapp:add_application')
        # follow=True автоматически обрабатывает редирект после успешного сохранения
        response = self.client.post(create_url, data=form_data, follow=True)

        # 5. Проверить, что произошел редирект на страницу списка заявок (HTTP 200 OK после follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, reverse('creditapp:application_list'))

        # 6. Проверить изменение состояния системы (количество объектов увеличилось на 1)
        final_count = CreditApplication.objects.filter(user=user).count()
        self.assertEqual(final_count, 1)

        # 7. Проверить, что данные корректно сохранены в БД
        new_app = CreditApplication.objects.get(full_name='Интеграционный Тест')
        self.assertEqual(new_app.user, user)
        self.assertEqual(new_app.amount, Decimal('150000.00'))
        self.assertEqual(new_app.status, 'pending') # Проверка дефолтного статуса

        # 8. Проверить, что новая заявка отображается на странице списка заявок
        self.assertContains(response, '150000,00 руб.')

class SecurityTests(TestCase):

    def setUp(self):
        self.user = CustomUser.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='securepassword123',
            phone_number='+79001234567',
            date_of_birth=date(1985, 3, 20)
        )
        self.admin_user = CustomUser.objects.create_superuser(
            username='adminuser',
            email='admin@example.com',
            password='adminpassword123'
        )
        self.product = LoanProduct.objects.create(
            name='Ипотека',
            max_amount=1000000,
            interest_rate=11.5
        )

    def test_sql_injection_protection(self):
        """Проверка, что ORM не выполняет SQL-код в поле full_name."""
        sql_payload = "'; DROP TABLE creditapp_creditapplication; --"

        application = CreditApplication.objects.create(
            user=self.user,
            product=self.product,
            amount=1500000,
            status='pending',
            full_name=sql_payload,
            income=700000,
            loan_term=36,
            interest_rate=11.5
        )

        # Проверяем, что поле сохранилось как строка, а не выполнил SQL
        saved = CreditApplication.objects.get(id=application.id)
        self.assertEqual(saved.full_name, sql_payload)
        self.assertTrue(CreditApplication.objects.exists())  # Таблица не удалена

    def test_delete_user_method_not_allowed(self):
        """Проверка, что GET-запрос на удаление пользователя возвращает 405 Method Not Allowed."""
        # Логинимся как админ
        self.client.login(username='adminuser', password='adminpassword123')

        # Пытаемся удалить через GET — должно быть 405
        response = self.client.get(
            reverse('creditapp:delete_user', args=[self.user.id])
        )

        # Ожидаем 405 — если в представлении стоит @require_http_methods(['POST'])
        self.assertEqual(response.status_code, 405)

    def test_xss_protection_in_application_list(self):
        malicious_name = "<script>alert('XSS')</script>"
        CreditApplication.objects.create(
            user=self.user,
            product=self.product,
            amount=1000000,
            status='approved',
            full_name=malicious_name,
            income=500000,
            loan_term=24,
            interest_rate=10.5
        )
        self.client.login(username='testuser', password='securepassword123')
        response = self.client.get(reverse('creditapp:application_list'))
        
        # Проверяем, что в HTML-выводе отображается экранированная версия
        self.assertContains(response, "&lt;script&gt;alert(&#x27;XSS&#x27;)&lt;/script&gt;")
        # Проверяем, что в сырой HTML-странице нет неэкранированных тегов <script>
        self.assertNotIn(b"<script>", response.content)


    

    