# Чек-дист тестировагия

## Функциональность
- [x] Все ссылки и кнопки работают, нет 404.
- [x] Формы валидируются, ошибки подсвечиваются.
- [x] После успешной отправки формы — сохранение/редирект.
- [x] Полный цикл основной услуги: добавление отзыва к услуге — работает.

## Права доступа
- [x] Гость не попадает в закрытые разделы.
- [x] Пользователь не попадает в админ-панель.
- [x] Админ имеет полный доступ и видит отчёты XLSX.

## Юзабилити
- [x] Адаптивность: ПК, планшет, смартфон — ок.
- [x] Элементы не наезжают, текст читаем.
- [x] Медиа загружаются корректно.
- [x] CSS применены ко всем элементам.

## Надёжность
- [x] Кастомная 404 на несуществующей странице.
- [x] Ошибки обрабатываются, приложение не падает.
- [x] Некорректные данные не ломают систему.

## Производительность
- [x] Основные страницы грузятся ≤ 2–3 сек.
- [x] Нет N+1: списки не вызывают сотни запросов.

<!--{% load static %}
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>{% block title %}Кредитная система{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="{% static 'style.css' %}">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="{% url 'creditapp:home' %}">КредитСистема</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Переключить навигацию">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        {% if user.is_authenticated %}
          <li class="nav-item">
            <a class="nav-link" href="{% url 'creditapp:application_list' %}">Мои заявки</a>
          </li>
          {% if user.is_staff %}
            <li class="nav-item">
              <a class="nav-link" href="{% url 'creditapp:admin_dashboard' %}">Страница администратора</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="{% url 'creditapp:admin_report' %}">Отчет</a>
            </li>
          {% endif %}
          <li class="nav-item">
            <a class="nav-link" href="{% url 'creditapp:logout' %}">Выход</a>
          </li>
        {% else %}
          <li class="nav-item">
            <a class="nav-link" href="{% url 'creditapp:login' %}">Вход</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{% url 'creditapp:register' %}">Регистрация</a>
          </li>
        {% endif %}
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
  {% if messages %}
    {% for message in messages %}
      <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
        {{ message }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Закрыть"></button>
      </div>
    {% endfor %}
  {% endif %}
  {% block content %}{% endblock %}
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>-->